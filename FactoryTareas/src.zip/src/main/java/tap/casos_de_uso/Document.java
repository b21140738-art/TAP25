package tap.casos_de_uso;

public interface Document {
    void open();
    void save();
}
