package tap.casos_de_uso;

public class DocxDocument implements Document{
    public void   open(){}
    public void save(){}
}
