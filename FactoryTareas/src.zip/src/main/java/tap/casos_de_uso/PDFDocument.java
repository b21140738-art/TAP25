package tap.casos_de_uso;

public class PDFDocument implements Document{
    public void   open(){
    }
    public void save(){
    }

}

