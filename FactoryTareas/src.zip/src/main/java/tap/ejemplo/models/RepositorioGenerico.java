package tap.ejemplo.models;

import java.util.ArrayList;
import java.util.List;

public class RepositorioGenerico<T> {
    private final List<T> elementos = new ArrayList<>();

    public void add(T elemento) {
        elementos.add(elemento);
    }
    public List<T> getElementos() {
        return elementos;
    }
}
