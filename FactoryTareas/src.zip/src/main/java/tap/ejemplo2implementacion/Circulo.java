package tap.ejemplo2implementacion;

class Circulo
{
    public void dibujar()
    {
        System.out.println("Dibujando un Circulo");
    }
}

class Cuadrado implements Figura{
    public void dibujar()
    {
        System.out.println("Cuadrado Dibujo");
    }
}
