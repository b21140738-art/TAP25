package tap.ejemplo2implementacion;

public interface Figura {
    void dibujar();
}
