package tap.Implementación_del_Patron_Factory_en_Java;

public interface Vehiculo {
    void conducir();
}
