package tap.factory;

public interface Car {
    void assemble();
}
