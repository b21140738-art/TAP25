package tap.factory;

public interface CarFactory {
    Car createCar();

}
