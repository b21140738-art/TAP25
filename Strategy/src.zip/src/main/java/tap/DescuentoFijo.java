package tap;

/**
 * Descuento fijo del 10%.
 */
public class DescuentoFijo implements EstrategiaDescuento {
    @Override
    public double aplicarDescuento(double precioOriginal) {
        return precioOriginal * 0.90;
    }
}

/**
 * Descuento por temporada: 25%.
 */
public class DescuentoTemporada implements EstrategiaDescuento {
    @Override
    public double aplicarDescuento(double precioOriginal) {
        return precioOriginal * 0.75;
    }
}

/**
 * Sin descuento aplicado.
 */
public class SinDescuento implements EstrategiaDescuento {
    @Override
    public double aplicarDescuento(double precioOriginal) {
        return precioOriginal;
    }
}
